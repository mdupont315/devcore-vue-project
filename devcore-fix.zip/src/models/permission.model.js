import BaseModel from "./base.model";

export default class PermissionModel extends BaseModel {

}