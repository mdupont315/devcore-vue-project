import BaseModel from "./base.model";

export default class IdeaReport extends BaseModel {}