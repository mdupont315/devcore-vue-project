import BaseModel from "./base.model";

export default class CompanyToolPriceModel extends BaseModel {
    modules = [];

    _showDetails = false;
}