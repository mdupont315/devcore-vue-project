import BaseModel from "./base.model";

export default class UserProjectReport extends BaseModel {}