export default {
  FORMAT_DATE: 'MM/DD/YYYY',
  FORMAT_TIME: 'hh:mm:ss',
  FORMAT_DATETIME: 'MM/DD/YYYY hh:mm:ss'
}
