export default {
    PERM_COMPANY_MANAGE: 'core/company/manage',
    FORMAT_TIME: 'hh:mm:ss',
    FORMAT_DATETIME: 'MM/DD/YYYY hh:mm:ss'
  }
  