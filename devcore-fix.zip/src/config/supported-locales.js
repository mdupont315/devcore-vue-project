export default {
    en: "English",
    fi: "Finnish (Finnish)"
  }