export const API_PORT = "5000";
export const API_URL = `http://localhost:${API_PORT}`;
export const DOMAIN_TITLE = "supersite.com";
