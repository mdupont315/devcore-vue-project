/**
 * import and init global plugins
 */

import Vue from 'vue'

import globalEventBus from "./globalEventBus"

Vue.use(globalEventBus)
