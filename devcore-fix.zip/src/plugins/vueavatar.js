import Vue from 'vue';
import Avatar from 'vue-avatar';

Vue.component('v-avatar', Avatar);