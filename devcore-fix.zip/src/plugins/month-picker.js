import Vue from 'vue';
import VueMonthlyPicker from 'vue-monthly-picker'

Vue.component('month-picker', {
    components: {
        VueMonthlyPicker
    }
});