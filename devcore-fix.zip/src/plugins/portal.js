import PortalVue from 'portal-vue'
import Vue from 'vue'

Vue.use(PortalVue)