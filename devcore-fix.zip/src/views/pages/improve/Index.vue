<template>
      <router-view></router-view>
</template>
<script>
export default {
   
  data: () => ({
    currentComponent: null
  }),
 
};
</script>