import { render, staticRenderFns } from "./UserReportChart.vue?vue&type=template&id=4e4d332b&"
import script from "./UserReportChart.vue?vue&type=script&lang=js&"
export * from "./UserReportChart.vue?vue&type=script&lang=js&"


/* normalize component */
import normalizer from "!../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js"
var component = normalizer(
  script,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

export default component.exports